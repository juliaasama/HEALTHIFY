import sqlite3

def init_db():
    conn = sqlite3.connect('healthify.db')
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute("""CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT, email TEXT UNIQUE, phone TEXT, password TEXT, role TEXT)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS providers (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, full_name TEXT NOT NULL, specialty TEXT NOT NULL, rating REAL DEFAULT 0, available_days TEXT, available_time TEXT, image_url TEXT, FOREIGN KEY (user_id) REFERENCES users(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS Time_Slots (slot_id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER NOT NULL, appointment_date DATE NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, is_available INTEGER DEFAULT 1, note TEXT DEFAULT '', FOREIGN KEY (provider_id) REFERENCES providers(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS appointments (id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER, provider_name TEXT, patient_name TEXT, appointment_date TEXT, appointment_time TEXT, status TEXT DEFAULT 'Pending', customer_id INTEGER, slot_id INTEGER, FOREIGN KEY (provider_id) REFERENCES providers(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS Notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, is_read INTEGER DEFAULT 0, sent_at TEXT DEFAULT (datetime('now')), FOREIGN KEY (user_id) REFERENCES users(id))""")
    
    # Insert admin user
    try:
        cursor.execute("INSERT INTO users (first_name,last_name,email,phone,password,role) VALUES ('Admin','Healthify','admin@healthify.com','09000000000','admin123','Administrator')")
    except sqlite3.IntegrityError:
        print("Admin user already exists")
    
    # Insert provider users
    provider_users = [
        ("Julia","Tiongson","julia@healthify.ph","09111111111","doctor123","Service Provider"),
        ("Catherine","Ore","catherine@healthify.ph","09111111112","doctor123","Service Provider"),
        ("James","Nipaya","james@healthify.ph","09111111113","doctor123","Service Provider"),
        ("Jhanna","Hangad","jhanna@healthify.ph","09111111114","doctor123","Service Provider"),
        ("Jan Rey","Sayson","janrey@healthify.ph","09111111115","doctor123","Service Provider"),
    ]
    
    for pu in provider_users:
        try:
            cursor.execute("INSERT INTO users (first_name,last_name,email,phone,password,role) VALUES (?,?,?,?,?,?)", pu)
        except sqlite3.IntegrityError:
            print(f"User {pu[2]} already exists")
    
    # Insert providers
    provider_data = [
        ("julia@healthify.ph","Dr. Julia Tiongson","Dermatologist",4.8,"Mon-Fri","9:00 AM - 4:00 PM","julia.png"),
        ("catherine@healthify.ph","Dr. Catherine Ore","Dentist",4.9,"Mon-Fri","9:00 AM - 3:00 PM","catherine.png"),
        ("james@healthify.ph","Dr. James Nipaya","Optometrist",4.9,"Mon-Fri","10:00 AM - 6:00 PM","james.png"),
        ("jhanna@healthify.ph","Dr. Jhanna Rose Hangad","Nutritionist",4.8,"Mon-Fri","9:00 AM - 5:00 PM","jhanna.png"),
        ("janrey@healthify.ph","Dr. Jan Rey Sayson","Physical Therapist",4.9,"Mon-Fri","10:00 AM - 7:00 PM","janrey.png"),
    ]
    
    for pd in provider_data:
        user_row = cursor.execute("SELECT id FROM users WHERE email=?", (pd[0],)).fetchone()
        if user_row:
            uid = user_row[0]
            try:
                cursor.execute("INSERT INTO providers (user_id,full_name,specialty,rating,available_days,available_time,image_url) VALUES (?,?,?,?,?,?,?)", (uid,pd[1],pd[2],pd[3],pd[4],pd[5],pd[6]))
            except sqlite3.IntegrityError:
                print(f"Provider {pd[1]} already exists")
    
    conn.commit()
    conn.close()
    print("Database initialized successfully!")

if __name__ == '__main__':
    init_db()