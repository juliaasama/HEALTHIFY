import sqlite3

conn = sqlite3.connect('healthify.db')
cursor = conn.cursor()

# Check if admin account exists
cursor.execute("SELECT * FROM users WHERE role='Administrator'")
admin_users = cursor.fetchall()

print("Admin users found:")
for user in admin_users:
    print(f"ID: {user[0]}, Name: {user[1]} {user[2]}, Email: {user[3]}, Role: {user[6]}")

# Check all users
cursor.execute("SELECT * FROM users")
all_users = cursor.fetchall()

print("\nAll users:")
for user in all_users:
    print(f"ID: {user[0]}, Name: {user[1]} {user[2]}, Email: {user[3]}, Role: {user[6]}")

conn.close()