from flask import Flask, render_template, request, redirect, session, url_for, jsonify
import sqlite3
from datetime import date

app = Flask(__name__)
app.secret_key = 'healthify_secret_key'

import os
DB_NAME = os.path.join(os.path.dirname(__file__), '..', 'healthify.db')

def get_db():
    conn = sqlite3.connect(DB_NAME, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT, email TEXT UNIQUE, phone TEXT, password TEXT, role TEXT)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS providers (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, full_name TEXT NOT NULL, specialty TEXT NOT NULL, rating REAL DEFAULT 0, available_days TEXT, available_time TEXT, image_url TEXT, FOREIGN KEY (user_id) REFERENCES users(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS Time_Slots (slot_id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER NOT NULL, appointment_date DATE NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, is_available INTEGER DEFAULT 1, FOREIGN KEY (provider_id) REFERENCES providers(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS appointments (id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER, provider_name TEXT, patient_name TEXT, appointment_date TEXT, appointment_time TEXT, status TEXT DEFAULT 'Pending', customer_id INTEGER, slot_id INTEGER, FOREIGN KEY (provider_id) REFERENCES providers(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS Notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, is_read INTEGER DEFAULT 0, sent_at TEXT DEFAULT (datetime('now')), FOREIGN KEY (user_id) REFERENCES users(id))""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS Feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, appointment_id INTEGER, patient_id INTEGER, provider_id INTEGER, rating INTEGER, comment TEXT, created_at TEXT DEFAULT (datetime('now')), FOREIGN KEY (appointment_id) REFERENCES appointments(id), FOREIGN KEY (patient_id) REFERENCES users(id), FOREIGN KEY (provider_id) REFERENCES providers(id))""")
    # Migrations — safe to run every time, skipped if column already exists
    for migration in [
        "ALTER TABLE providers ADD COLUMN user_id INTEGER",
        "ALTER TABLE appointments ADD COLUMN customer_id INTEGER",
        "ALTER TABLE appointments ADD COLUMN slot_id INTEGER",
        "ALTER TABLE Time_Slots ADD COLUMN note TEXT DEFAULT ''",  # for blocked-slot reasons
    ]:
        try:
            cursor.execute(migration)
            conn.commit()
        except sqlite3.OperationalError:
            pass
    conn.commit()
    conn.close()

def seed_data():
    conn = get_db()
    cursor = conn.cursor()
    provider_users = [
        ("Julia","Tiongson","julia@healthify.ph","09111111111","doctor123","Service Provider"),
        ("Catherine","Ore","catherine@healthify.ph","09111111112","doctor123","Service Provider"),
        ("James","Nipaya","james@healthify.ph","09111111113","doctor123","Service Provider"),
        ("Jhanna","Hangad","jhanna@healthify.ph","09111111114","doctor123","Service Provider"),
        ("Jan Rey","Sayson","janrey@healthify.ph","09111111115","doctor123","Service Provider"),
    ]
    for pu in provider_users:
        cursor.execute("INSERT OR IGNORE INTO users (first_name,last_name,email,phone,password,role) VALUES (?,?,?,?,?,?)", pu)
    conn.commit()
    provider_data = [
        ("julia@healthify.ph","Dr. Julia Tiongson","Dermatologist",4.8,"Mon-Fri","9:00 AM - 4:00 PM","julia.png"),
        ("catherine@healthify.ph","Dr. Catherine Ore","Dentist",4.9,"Mon-Fri","9:00 AM - 3:00 PM","catherine.png"),
        ("james@healthify.ph","Dr. James Nipaya","Optometrist",4.9,"Mon-Fri","10:00 AM - 6:00 PM","james.png"),
        ("jhanna@healthify.ph","Dr. Jhanna Rose Hangad","Nutritionist",4.8,"Mon-Fri","9:00 AM - 5:00 PM","jhanna.png"),
        ("janrey@healthify.ph","Dr. Jan Rey Sayson","Physical Therapist",4.9,"Mon-Fri","10:00 AM - 7:00 PM","janrey.png"),
    ]
    for pd in provider_data:
        user_row = cursor.execute("SELECT id FROM users WHERE email=?", (pd[0],)).fetchone()
        if user_row:
            uid = user_row[0]
            if not cursor.execute("SELECT id FROM providers WHERE user_id=?", (uid,)).fetchone():
                cursor.execute("INSERT INTO providers (user_id,full_name,specialty,rating,available_days,available_time,image_url) VALUES (?,?,?,?,?,?,?)", (uid,pd[1],pd[2],pd[3],pd[4],pd[5],pd[6]))
    # Ensure requested default admin account exists and credentials are aligned
    cursor.execute("UPDATE users SET email='admin@healthify.ph', password='admin123' WHERE role='Administrator' AND email='admin@healthify.com'")
    cursor.execute("UPDATE users SET password='admin123', role='Administrator' WHERE email='admin@healthify.ph'")
    cursor.execute("INSERT OR IGNORE INTO users (first_name,last_name,email,phone,password,role) VALUES ('Admin','Healthify','admin@healthify.ph','09000000000','admin123','Administrator')")
    conn.commit()
    conn.close()

def get_provider_for_user(email):
    db = get_db()
    provider = db.execute('''SELECT u.id AS user_id, u.first_name, u.last_name, u.email, u.phone, p.id AS provider_id, p.specialty AS specialization, p.full_name, p.available_days, p.available_time, p.image_url FROM users u JOIN providers p ON p.user_id = u.id WHERE u.email = ?''', (email,)).fetchone()
    db.close()
    return provider

def send_notification(user_id, message, conn=None):
    """Helper to send a notification to a user by user_id.

    If a DB connection is provided, reuse it to avoid nested write locks.
    """
    if conn is not None:
        conn.execute("INSERT INTO Notifications (user_id, message) VALUES (?, ?)", (user_id, message))
        return

    db = get_db()
    db.execute("INSERT INTO Notifications (user_id, message) VALUES (?, ?)", (user_id, message))
    db.commit()
    db.close()

def get_user_by_email(email):
    """Helper to get user row by email"""
    db = get_db()
    user = db.execute("SELECT id, first_name FROM users WHERE email=?", (email,)).fetchone()
    db.close()
    return user

def get_unread_notifications_count(user_email):
    """Return unread notification count for a user email."""
    if not user_email:
        return 0
    db = get_db()
    user_row = db.execute("SELECT id FROM users WHERE email=?", (user_email,)).fetchone()
    if not user_row:
        db.close()
        return 0
    unread_count = db.execute(
        "SELECT COUNT(*) FROM Notifications WHERE user_id=? AND is_read=0",
        (user_row['id'],)
    ).fetchone()[0]
    db.close()
    return unread_count

@app.context_processor
def inject_notification_badge_count():
    """Inject unread notification count into all templates."""
    user = session.get('user')
    if not user:
        return {'unread_notifications_count': 0}
    return {'unread_notifications_count': get_unread_notifications_count(user.get('email'))}

@app.route('/')
def index():
    conn = get_db()
    providers = conn.execute("SELECT * FROM providers").fetchall()
    conn.close()
    user = session.get('user')
    return render_template('index.html', providers=providers, user=user)

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    error = None
    if request.method == 'POST':
        email = request.form['email'].strip().lower()
        password = request.form['password'].strip()
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password)).fetchone()
        db.close()
        if user:
            session['user'] = {'name': user['first_name'], 'email': user['email'], 'role': user['role']}
            if user['role'] == 'Service Provider':
                return redirect('/provider/dashboard')
            elif user['role'] == 'Administrator':
                return redirect('/admin/dashboard')
            else:
                return redirect(url_for('index'))
        else:
            error = 'Invalid email or password.'
    return render_template('sign-in.html', error=error)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        phone = request.form['phone']
        password = request.form['password']
        role = request.form.get('role', 'Customer')
        db = get_db()
        try:
            db.execute('INSERT INTO users (first_name,last_name,email,phone,password,role) VALUES (?,?,?,?,?,?)', (first_name,last_name,email,phone,password,role))
            db.commit()
        except sqlite3.IntegrityError:
            db.close()
            return render_template('register.html', error='Email already exists.')
        db.close()
        session['user'] = {'name': first_name, 'email': email, 'role': role}
        if role == 'Service Provider':
            return redirect('/provider/dashboard')
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    user = session.get('user')
    if not user:
        return redirect('/signin')
    conn = get_db()
    providers = conn.execute("SELECT * FROM providers").fetchall()
    appointments = conn.execute("""SELECT a.*, p.full_name as provider_name FROM appointments a LEFT JOIN providers p ON a.provider_id = p.id WHERE a.patient_name = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC""", (user['name'],)).fetchall()
    stats = {
        'total': len(appointments),
        'pending': len([a for a in appointments if a['status'] in ('Pending', 'Awaiting Approval')]),
        'completed': len([a for a in appointments if a['status'] in ('Completed', 'Confirmed')]),
        'cancelled': len([a for a in appointments if a['status'] == 'Cancelled'])
    }
    conn.close()
    return render_template('dashboard.html', user=user, providers=providers, appointments=appointments, stats=stats)

@app.route('/appointments')
def appointments():
    user = session.get('user')
    if not user:
        return redirect('/signin')
    db = get_db()
    appts = db.execute("""SELECT a.*, p.full_name as provider_name FROM appointments a LEFT JOIN providers p ON a.provider_id = p.id WHERE a.patient_name = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC""", (user['name'],)).fetchall()
    db.close()
    return render_template('appointment.html', appointments=appts, user=user)

@app.route('/book_appointment', methods=['POST'])
def book_appointment():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
    data = request.get_json()
    provider_name = data.get('provider_name', '').strip()
    appointment_date = data.get('appointment_date', '').strip()
    appointment_time = data.get('appointment_time', '').strip()
    if not provider_name or not appointment_date or not appointment_time:
        return jsonify({'success': False, 'message': 'Missing fields'}), 400
    conn = None
    try:
        conn = get_db()
        provider = conn.execute("SELECT id FROM providers WHERE full_name=?", (provider_name,)).fetchone()
        pid = provider['id'] if provider else None

        # Check if this slot is already booked (non-cancelled appointment at same time)
        existing = conn.execute("""
            SELECT id FROM appointments
            WHERE provider_id=? AND appointment_date=? AND appointment_time=?
            AND status NOT IN ('Cancelled')
        """, (pid, appointment_date, appointment_time)).fetchone()
        if existing:
            conn.close()
            return jsonify({'success': False, 'message': 'This time slot is already booked. Please choose another.'})

        # Get logged-in user id for customer_id
        user_row = conn.execute("SELECT id FROM users WHERE email=?", (user['email'],)).fetchone()
        cid = user_row['id'] if user_row else None

        # Insert appointment with status 'Awaiting Approval'
        conn.execute("""INSERT INTO appointments
            (provider_id, provider_name, patient_name, appointment_date, appointment_time, status, customer_id)
            VALUES (?,?,?,?,?,'Awaiting Approval',?)""",
            (pid, provider_name, user['name'], appointment_date, appointment_time, cid))

        # Map display time → 24h start hour so we can find the matching Time_Slot
        TIME_TO_HOUR = {
            '9:00 - 10:00 AM': 9, '10:00 - 11:00 AM': 10, '11:00 - 12:00 PM': 11,
            '1:00 - 2:00 PM': 13, '2:00 - 3:00 PM': 14,  '3:00 - 4:00 PM': 15,
            '4:00 - 5:00 PM': 16, '5:00 - 6:00 PM': 17,
        }
        start_hour = TIME_TO_HOUR.get(appointment_time)
        if pid and start_hour is not None:
            # Mark the matching available Time_Slot as booked (is_available=0)
            conn.execute("""
                UPDATE Time_Slots SET is_available=0
                WHERE provider_id=? AND appointment_date=? AND is_available=1
                AND CAST(SUBSTR(start_time,1,INSTR(start_time,':')-1) AS INTEGER) = ?
            """, (pid, appointment_date, start_hour))

        # Send notification to provider about new booking
        if pid and cid:
            provider_user = conn.execute("SELECT id FROM users WHERE id IN (SELECT user_id FROM providers WHERE id=?)", (pid,)).fetchone()
            if provider_user:
                # Reuse current transaction connection to prevent SQLITE_BUSY/locked errors
                send_notification(provider_user['id'], f"New appointment request from {user['name']} on {appointment_date} at {appointment_time}", conn=conn)

        # Send notification to customer confirming request submission
        if cid:
            send_notification(cid, f"Your appointment request with {provider_name} on {appointment_date} at {appointment_time} was submitted.", conn=conn)

        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': 'Appointment booked!'})
    except Exception as e:
        if conn is not None:
            try:
                conn.rollback()
                conn.close()
            except Exception:
                pass
        return jsonify({'success': False, 'message': str(e)}), 500

def send_notification_to_user_id(user_id, message):
    """Backward-compatible wrapper."""
    send_notification(user_id, message)

@app.route('/update_appointment/<int:appt_id>', methods=['POST'])
def update_appointment(appt_id):
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
    data = request.get_json()
    appointment_date = data.get('appointment_date', '').strip()
    appointment_time = data.get('appointment_time', '').strip()
    if not appointment_date or not appointment_time:
        return jsonify({'success': False, 'message': 'Missing fields'}), 400
    try:
        conn = get_db()
        appt = conn.execute("SELECT * FROM appointments WHERE id=? AND patient_name=?", (appt_id, user['name'])).fetchone()
        if not appt:
            conn.close()
            return jsonify({'success': False, 'message': 'Not found'}), 404
        if appt['status'] == 'Cancelled':
            conn.close()
            return jsonify({'success': False, 'message': 'Cannot update cancelled'}), 400
        conn.execute("UPDATE appointments SET appointment_date=?,appointment_time=?,status='Pending' WHERE id=? AND patient_name=?", (appointment_date,appointment_time,appt_id,user['name']))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/cancel_appointment/<int:appt_id>', methods=['POST'])
def cancel_appointment(appt_id):
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
    try:
        conn = get_db()
        appt = conn.execute("SELECT * FROM appointments WHERE id=? AND patient_name=?", (appt_id, user['name'])).fetchone()
        if not appt:
            conn.close()
            return jsonify({'success': False, 'message': 'Not found'}), 404
        if appt['status'] == 'Cancelled':
            conn.close()
            return jsonify({'success': False, 'message': 'Already cancelled'}), 400
        conn.execute("UPDATE appointments SET status='Cancelled' WHERE id=? AND patient_name=?", (appt_id, user['name']))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/book/<int:provider_id>', methods=['POST'])
def book(provider_id):
    name = request.form['patient_name']
    dt = request.form['date']
    tm = request.form['time']
    conn = get_db()
    conn.execute("INSERT INTO appointments (provider_id,patient_name,appointment_date,appointment_time) VALUES (?,?,?,?)", (provider_id,name,dt,tm))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    user = session.get('user')
    if not user:
        return redirect('/signin')
    if request.method == 'POST':
        db = get_db()
        db.execute('UPDATE users SET first_name=?,last_name=?,email=?,phone=? WHERE email=?', (request.form['first_name'],request.form['last_name'],request.form['email'],request.form['phone'],user['email']))
        db.commit()
        db.close()
        session['user']['name'] = request.form['first_name']
        return '', 200
    db = get_db()
    u = db.execute('SELECT * FROM users WHERE email=?', (user['email'],)).fetchone()
    db.close()
    return render_template('profile.html', user=u)

@app.route('/notifications')
def notifications():
    user = session.get('user')
    if not user:
        return redirect('/signin')
    db = get_db()
    user_row = db.execute('SELECT id FROM users WHERE email=?', (user['email'],)).fetchone()
    if user_row:
        notifs = db.execute('SELECT * FROM Notifications WHERE user_id=? ORDER BY sent_at DESC', (user_row['id'],)).fetchall()
    else:
        notifs = []
    db.close()
    return render_template('notification.html', notifications=notifs, user=user)


@app.route('/notifications/mark-read/<int:notif_id>', methods=['POST'])
def mark_notification_read(notif_id):
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    db = get_db()
    user_row = db.execute('SELECT id FROM users WHERE email=?', (user['email'],)).fetchone()
    if not user_row:
        db.close()
        return jsonify({'success': False, 'message': 'User not found'}), 404

    db.execute(
        'UPDATE Notifications SET is_read=1 WHERE id=? AND user_id=?',
        (notif_id, user_row['id'])
    )
    db.commit()
    db.close()
    return jsonify({'success': True})


@app.route('/notifications/mark-all-read', methods=['POST'])
def mark_all_notifications_read():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    db = get_db()
    user_row = db.execute('SELECT id FROM users WHERE email=?', (user['email'],)).fetchone()
    if not user_row:
        db.close()
        return jsonify({'success': False, 'message': 'User not found'}), 404

    db.execute(
        'UPDATE Notifications SET is_read=1 WHERE user_id=?',
        (user_row['id'],)
    )
    db.commit()
    db.close()
    return jsonify({'success': True})

@app.route('/notifications/clear-all', methods=['POST'])
def clear_all_notifications():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    db = get_db()
    user_row = db.execute('SELECT id FROM users WHERE email=?', (user['email'],)).fetchone()
    if not user_row:
        db.close()
        return jsonify({'success': False, 'message': 'User not found'}), 404

    db.execute(
        'DELETE FROM Notifications WHERE user_id=?',
        (user_row['id'],)
    )
    db.commit()
    db.close()
    return jsonify({'success': True})

@app.route('/doctor')
@app.route('/doctors')
def doctors():
    user = session.get('user')
    if not user:
        return redirect('/signin')
    return render_template('doctor.html', user=user)


# ============================================================
# API: SLOT AVAILABILITY FOR PATIENT BOOKING PAGE
# Called by appointment.html fetchSlotAvailability()
# Returns which slots are blocked/available for a doctor+date
# ============================================================
@app.route('/api/slots')
def api_get_slots():
    provider_name = request.args.get('provider', '').strip()
    slot_date     = request.args.get('date', '').strip()

    if not provider_name or not slot_date:
        return jsonify({'slots': []})

    db = get_db()
    provider = db.execute("SELECT id FROM providers WHERE full_name=?", (provider_name,)).fetchone()
    if not provider:
        db.close()
        return jsonify({'slots': []})

    rows = db.execute(
        "SELECT start_time, end_time, is_available, note FROM Time_Slots WHERE provider_id=? AND appointment_date=? ORDER BY start_time",
        (provider['id'], slot_date)
    ).fetchall()
    db.close()

    # All 8 standard 1-hour slots shown in appointment.html, in order
    # Each entry: (start_hour_24, display_label)
    STANDARD_SLOTS = [
        (9,  '9:00 - 10:00 AM'),
        (10, '10:00 - 11:00 AM'),
        (11, '11:00 - 12:00 PM'),
        (13, '1:00 - 2:00 PM'),
        (14, '2:00 - 3:00 PM'),
        (15, '3:00 - 4:00 PM'),
        (16, '4:00 - 5:00 PM'),
        (17, '5:00 - 6:00 PM'),
    ]

    def parse_hour(t):
        """Parse time string to integer hour. Handles 09:00, 9:00, 16:00 etc."""
        try:
            return int(str(t).split(':')[0])
        except:
            return -1

    # Build blocked/available ranges from DB rows
    # Each DB row covers start_time to end_time
    # A row with is_available=0 blocks ALL standard slots within that range
    result_map = {}  # label -> {available, note}
    STANDARD_SLOTS_LABELS = {label for _, label in STANDARD_SLOTS}

    for row in rows:
        start_h = parse_hour(row['start_time'])
        end_h   = parse_hour(row['end_time']) if row['end_time'] else start_h + 1
        is_avail = bool(row['is_available'])
        note     = row['note'] or ''

        # Find all standard slots that fall within [start_h, end_h)
        for slot_h, label in STANDARD_SLOTS:
            if start_h <= slot_h < end_h:
                # If this range is blocked, mark it (don't override a block with available)
                if label not in result_map or not is_avail:
                    result_map[label] = {'available': is_avail, 'note': note}

    # ALSO check existing appointments for this provider+date — booked = unavailable
    appt_rows = db.execute("""
        SELECT appointment_time FROM appointments
        WHERE provider_id=? AND appointment_date=? AND status NOT IN ('Cancelled')
    """, (provider['id'], slot_date)).fetchall() if False else []

    # re-open db (it was closed above — reopen for appointment check)
    db2 = get_db()
    provider2 = db2.execute("SELECT id FROM providers WHERE full_name=?", (provider_name,)).fetchone()
    appt_rows = db2.execute("""
        SELECT appointment_time FROM appointments
        WHERE provider_id=? AND appointment_date=? AND status NOT IN ('Cancelled')
    """, (provider2['id'], slot_date)).fetchall() if provider2 else []
    db2.close()

    # Map booked appointment_time display labels → blocked
    for row in appt_rows:
        t = row['appointment_time']
        if t in STANDARD_SLOTS_LABELS:
            if t not in result_map:  # don't override an explicit block
                result_map[t] = {'available': False, 'note': 'Already booked'}

    result = [
        {'time': label, 'available': v['available'], 'note': v['note']}
        for label, v in result_map.items()
    ]

    return jsonify({'slots': result})


# ============================================================
# PROVIDER ROUTES
# ============================================================

@app.route('/provider/dashboard')
def provider_dashboard():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if not provider:
        return redirect('/signin')
    db = get_db()
    pid = provider['provider_id']
    total     = db.execute('SELECT COUNT(*) FROM appointments WHERE provider_id=?', (pid,)).fetchone()[0]
    pending   = db.execute("SELECT COUNT(*) FROM appointments WHERE provider_id=? AND status='Awaiting Approval'", (pid,)).fetchone()[0]
    confirmed = db.execute("SELECT COUNT(*) FROM appointments WHERE provider_id=? AND status='Confirmed'", (pid,)).fetchone()[0]
    slots     = db.execute("SELECT COUNT(*) FROM Time_Slots WHERE provider_id=? AND is_available=1", (pid,)).fetchone()[0]
    stats = {'total': total, 'pending': pending, 'confirmed': confirmed, 'slots': slots}

    appointments = db.execute('SELECT id AS appointment_id, patient_name, appointment_date, appointment_time, status FROM appointments WHERE provider_id=? ORDER BY appointment_date DESC, appointment_time DESC LIMIT 10', (pid,)).fetchall()
    db.close()
    return render_template('provider_dashboard.html', provider=provider, stats=stats, appointments=appointments)


@app.route('/provider/schedule-day')
def provider_schedule_day():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if not provider:
        return redirect('/signin')

    db = get_db()
    pid = provider['provider_id']

    today_str = date.today().isoformat()
    selected_day = request.args.get('day', today_str).strip()
    try:
        date.fromisoformat(selected_day)
    except ValueError:
        selected_day = today_str

    today_schedule = db.execute(
        """
        SELECT id AS appointment_id, patient_name, appointment_time, status
        FROM appointments
        WHERE provider_id=? AND appointment_date=? AND status != 'Cancelled'
        ORDER BY appointment_time ASC
        """,
        (pid, selected_day)
    ).fetchall()

    selected_patient = request.args.get('patient', '').strip()
    patient_schedule_all = []
    if selected_patient:
        patient_schedule_all = db.execute(
            """
            SELECT id AS appointment_id, appointment_date, appointment_time, status
            FROM appointments
            WHERE provider_id=? AND patient_name=?
            ORDER BY appointment_date DESC, appointment_time DESC
            """,
            (pid, selected_patient)
        ).fetchall()

    db.close()
    return render_template(
        'provider_schedule_day.html',
        provider=provider,
        today=today_str,
        schedule_day=selected_day,
        today_schedule=today_schedule,
        selected_patient=selected_patient,
        patient_schedule_all=patient_schedule_all
    )

@app.route('/provider/appointment')
def provider_appointments():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if not provider:
        return redirect('/signin')
    db = get_db()
    pid = provider['provider_id']
    time_slots = db.execute(
        'SELECT ts.slot_id, ts.appointment_date, ts.start_time, ts.end_time, ts.is_available, ts.note, a.id AS appointment_id, a.status AS appt_status, a.patient_name FROM Time_Slots ts LEFT JOIN appointments a ON a.slot_id = ts.slot_id WHERE ts.provider_id=? ORDER BY ts.appointment_date, ts.start_time',
        (pid,)
    ).fetchall()
    appointments = db.execute('SELECT id AS appointment_id, patient_name, appointment_date, appointment_time, status FROM appointments WHERE provider_id=? ORDER BY appointment_date DESC', (pid,)).fetchall()
    db.close()
    return render_template('provider_appointment.html', provider=provider, time_slots=time_slots, appointments=appointments, today=date.today().isoformat())

@app.route('/provider/add_slot', methods=['POST'])
def provider_add_slot():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider     = get_provider_for_user(user['email'])
    is_available = int(request.form.get('is_available', 1))  # 1=open, 0=blocked
    note         = request.form.get('note', '').strip()
    db = get_db()
    db.execute(
        'INSERT INTO Time_Slots (provider_id, appointment_date, start_time, end_time, is_available, note) VALUES (?,?,?,?,?,?)',
        (provider['provider_id'], request.form['appointment_date'], request.form['start_time'], request.form['end_time'], is_available, note)
    )
    db.commit()
    db.close()
    return redirect('/provider/appointment?success=1')

@app.route('/provider/delete_slot/<int:slot_id>', methods=['POST'])
def provider_delete_slot(slot_id):
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    db = get_db()
    db.execute('DELETE FROM Time_Slots WHERE slot_id=?', (slot_id,))
    db.commit()
    db.close()
    return redirect('/provider/appointment')

@app.route('/provider/approve/<int:appt_id>', methods=['POST'])
def provider_approve(appt_id):
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    db = get_db()
    # Get appointment details
    appt = db.execute('SELECT * FROM appointments WHERE id=?', (appt_id,)).fetchone()
    if not appt:
        db.close()
        return redirect('/provider/appointment')
    
    # Update appointment status to Confirmed
    db.execute("UPDATE appointments SET status='Confirmed' WHERE id=?", (appt_id,))
    db.commit()
    
    # Mark the corresponding Time_Slot as unavailable (blocked)
    if appt['provider_id'] and appt['appointment_date'] and appt['appointment_time']:
        TIME_TO_HOUR = {
            '9:00 - 10:00 AM': 9, '10:00 - 11:00 AM': 10, '11:00 - 12:00 PM': 11,
            '1:00 - 2:00 PM': 13, '2:00 - 3:00 PM': 14,  '3:00 - 4:00 PM': 15,
            '4:00 - 5:00 PM': 16, '5:00 - 6:00 PM': 17,
        }
        start_hour = TIME_TO_HOUR.get(appt['appointment_time'])
        if start_hour is not None:
            db.execute("""
                UPDATE Time_Slots SET is_available=0
                WHERE provider_id=? AND appointment_date=? AND is_available=1
                AND CAST(SUBSTR(start_time,1,INSTR(start_time,':')-1) AS INTEGER) = ?
            """, (appt['provider_id'], appt['appointment_date'], start_hour))
            db.commit()
    
    # Send notification to patient
    if appt['customer_id']:
        send_notification(appt['customer_id'], 'Your appointment has been confirmed by your doctor.', conn=db)
        db.commit()
    
    db.close()
    return redirect('/provider/appointment?approved=1')

@app.route('/provider/cancel/<int:appt_id>', methods=['POST'])
def provider_cancel(appt_id):
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    db = get_db()
    slot = db.execute('SELECT slot_id FROM appointments WHERE id=?', (appt_id,)).fetchone()
    if slot and slot['slot_id']:
        db.execute('UPDATE Time_Slots SET is_available=1 WHERE slot_id=?', (slot['slot_id'],))
    db.execute("UPDATE appointments SET status='Cancelled' WHERE id=?", (appt_id,))
    db.commit()
    appt = db.execute('SELECT customer_id FROM appointments WHERE id=?', (appt_id,)).fetchone()
    if appt and appt['customer_id']:
        db.execute("INSERT INTO Notifications (user_id,message) VALUES (?,?)", (appt['customer_id'],'Your appointment has been cancelled by the provider.'))
        db.commit()
    db.close()
    return redirect('/provider/appointment?cancelled=1')

@app.route('/provider/notification')
def provider_notifications():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if not provider:
        return redirect('/signin')
    db = get_db()
    user_row = db.execute('SELECT id FROM users WHERE email=?', (user['email'],)).fetchone()
    if user_row:
        notifs = db.execute('SELECT * FROM Notifications WHERE user_id=? ORDER BY sent_at DESC', (user_row['id'],)).fetchall()
    else:
        notifs = []
    db.close()
    return render_template('provider_notification.html', provider=provider, notifications=notifs)

@app.route('/provider/profile', methods=['GET', 'POST'])
def provider_profile():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if request.method == 'POST':
        db = get_db()
        db.execute('UPDATE users SET first_name=?,last_name=?,email=?,phone=? WHERE id=?', (request.form.get('first_name'),request.form.get('last_name'),request.form.get('email'),request.form.get('phone'),provider['user_id']))
        db.execute('UPDATE providers SET specialty=?,available_days=?,available_time=? WHERE id=?', (request.form.get('specialization'),request.form.get('available_days'),request.form.get('available_time'),provider['provider_id']))
        db.commit()
        db.close()
        session['user']['name'] = request.form.get('first_name', '')
        return '', 200
    return render_template('provider_profile.html', provider=provider)

@app.route('/provider/report')
def provider_report():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if not provider:
        return redirect('/signin')
    db = get_db()
    pid = provider['provider_id']
    appointments = db.execute('SELECT id AS appointment_id, patient_name, appointment_date, appointment_time, status FROM appointments WHERE provider_id=? ORDER BY appointment_date DESC', (pid,)).fetchall()
    total = len(appointments)
    stats = {'total': total, 'confirmed': len([a for a in appointments if a['status']=='Confirmed']), 'pending': len([a for a in appointments if a['status']=='Pending']), 'cancelled': len([a for a in appointments if a['status']=='Cancelled']), 'completed': len([a for a in appointments if a['status']=='Completed'])}
    db.close()
    return render_template('provider_report.html', provider=provider, appointments=appointments, stats=stats)

# ============================================================
# FEEDBACK ROUTES
# ============================================================

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
    data = request.get_json()
    appointment_id = data.get('appointment_id')
    rating = data.get('rating')
    comment = data.get('comment', '').strip()
    
    if not appointment_id or not rating:
        return jsonify({'success': False, 'message': 'Missing fields'}), 400
    
    try:
        conn = get_db()
        # Get appointment details
        appt = conn.execute('SELECT * FROM appointments WHERE id=?', (appointment_id,)).fetchone()
        if not appt:
            conn.close()
            return jsonify({'success': False, 'message': 'Appointment not found'}), 404
        
        # Get patient and provider IDs
        patient_row = conn.execute('SELECT id FROM users WHERE email=?', (user['email'],)).fetchone()
        patient_id = patient_row['id'] if patient_row else None
        
        # Check if feedback already exists
        existing = conn.execute('SELECT id FROM Feedback WHERE appointment_id=?', (appointment_id,)).fetchone()
        if existing:
            conn.close()
            return jsonify({'success': False, 'message': 'Feedback already submitted for this appointment'}), 400
        
        # Insert feedback
        conn.execute("""INSERT INTO Feedback (appointment_id, patient_id, provider_id, rating, comment) VALUES (?,?,?,?,?)""",
            (appointment_id, patient_id, appt['provider_id'], rating, comment))
        
        # Update appointment status to Completed
        conn.execute("UPDATE appointments SET status='Completed' WHERE id=?", (appointment_id,))
        
        # Send notification to provider
        if appt['provider_id']:
            provider_user = conn.execute("SELECT user_id FROM providers WHERE id=?", (appt['provider_id'],)).fetchone()
            if provider_user:
                send_notification(provider_user['user_id'], f"You received a {rating}-star feedback from {user['name']}!", conn=conn)

        # Send notification to patient confirming feedback submission
        if patient_id:
            send_notification(patient_id, f"Your feedback for {appt['provider_name']} has been submitted. Thank you!", conn=conn)
        
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': 'Thank you for your feedback!'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/get_appointment/<int:appt_id>')
def get_appointment(appt_id):
    user = session.get('user')
    if not user:
        return jsonify({'error': 'Not logged in'}), 401
    conn = get_db()
    appt = conn.execute('SELECT a.*, p.full_name as provider_name FROM appointments a LEFT JOIN providers p ON a.provider_id=p.id WHERE a.id=?', (appt_id,)).fetchone()
    if not appt:
        conn.close()
        return jsonify({'error': 'Not found'}), 404
    conn.close()
    return jsonify({
        'id': appt['id'],
        'provider_name': appt['provider_name'],
        'patient_name': appt['patient_name'],
        'appointment_date': appt['appointment_date'],
        'appointment_time': appt['appointment_time'],
        'status': appt['status']
    })

@app.route('/provider/feedback')
def provider_feedback():
    user = session.get('user')
    if not user or user.get('role') != 'Service Provider':
        return redirect('/signin')
    provider = get_provider_for_user(user['email'])
    if not provider:
        return redirect('/signin')
    db = get_db()
    pid = provider['provider_id']
    feedbacks = db.execute("""
        SELECT
            f.*,
            a.patient_name,
            a.appointment_date,
            a.appointment_time,
            u.first_name AS patient_first_name,
            u.last_name  AS patient_last_name,
            uc.first_name AS appt_patient_first_name,
            uc.last_name  AS appt_patient_last_name,
            COALESCE(u.first_name, uc.first_name, a.patient_name, 'Patient') AS display_patient_first,
            COALESCE(u.last_name,  uc.last_name,  '') AS display_patient_last
        FROM Feedback f
        JOIN appointments a ON f.appointment_id = a.id
        LEFT JOIN users u  ON f.patient_id   = u.id
        LEFT JOIN users uc ON a.customer_id  = uc.id
        WHERE f.provider_id=?
          AND a.status='Completed'
        ORDER BY f.created_at DESC
    """, (pid,)).fetchall()
    
    # Calculate average rating
    avg_result = db.execute("SELECT AVG(rating) as avg_rating FROM Feedback WHERE provider_id=?", (pid,)).fetchone()
    avg_rating = round(avg_result['avg_rating'], 1) if avg_result and avg_result['avg_rating'] else 0
    
    total_feedbacks = len(feedbacks)
    db.close()
    return render_template('provider_feedback.html', provider=provider, feedbacks=feedbacks, avg_rating=avg_rating, total_feedbacks=total_feedbacks)


# ============================================================
# ADMIN HELPER + ROUTES
# ============================================================
def admin_required():
    user = session.get('user')
    if not user or user.get('role') != 'Administrator':
        return None
    return user

@app.route('/admin/dashboard')
def admin_dashboard():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    all_appts = db.execute("SELECT a.*, p.full_name as provider_name FROM appointments a LEFT JOIN providers p ON a.provider_id=p.id ORDER BY a.appointment_date DESC LIMIT 10").fetchall()
    all_providers = db.execute("SELECT * FROM providers ORDER BY id").fetchall()
    total_appts = db.execute("SELECT COUNT(*) FROM appointments").fetchone()[0]
    completed   = db.execute("SELECT COUNT(*) FROM appointments WHERE status='Completed'").fetchone()[0]
    pending     = db.execute("SELECT COUNT(*) FROM appointments WHERE status='Pending'").fetchone()[0]
    cancelled   = db.execute("SELECT COUNT(*) FROM appointments WHERE status='Cancelled'").fetchone()[0]
    awaiting    = db.execute("SELECT COUNT(*) FROM appointments WHERE status='Awaiting Approval'").fetchone()[0]
    def pct(n): return int(n / total_appts * 100) if total_appts > 0 else 0
    stats = {'providers': db.execute("SELECT COUNT(*) FROM providers").fetchone()[0], 'total_appointments': total_appts, 'patients': db.execute("SELECT COUNT(*) FROM users WHERE role='Customer'").fetchone()[0], 'pending_today': pending, 'completed_pct': pct(completed), 'pending_pct': pct(pending), 'cancelled_pct': pct(cancelled), 'awaiting_pct': pct(awaiting)}
    db.close()
    return render_template('admin_dashboard.html', user=user, stats=stats, appointments=all_appts, providers=all_providers)

@app.route('/admin/appointments')
def admin_appointments():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    appts = db.execute("SELECT a.*, p.full_name as provider_name FROM appointments a LEFT JOIN providers p ON a.provider_id=p.id ORDER BY a.appointment_date DESC").fetchall()
    db.close()
    return render_template('admin_appointments.html', user=user, appointments=appts)

@app.route('/admin/appointments/delete/<int:appt_id>', methods=['POST'])
def admin_delete_appointment(appt_id):
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    db.execute('DELETE FROM appointments WHERE id=?', (appt_id,))
    db.commit()
    db.close()
    return redirect('/admin/appointments')

@app.route('/admin/timeslots')
def admin_timeslots():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    slots = db.execute("""
        SELECT
            ts.*,
            p.full_name as provider_name,
            a.patient_name,
            a.status as appointment_status,
            a.id as appointment_id
        FROM Time_Slots ts
        LEFT JOIN providers p ON ts.provider_id=p.id
        LEFT JOIN appointments a
            ON a.slot_id = ts.slot_id
           AND a.status != 'Cancelled'
        ORDER BY ts.appointment_date DESC, ts.start_time
    """).fetchall()
    db.close()
    return render_template('admin_timeslots.html', user=user, slots=slots)

@app.route('/admin/timeslots/delete/<int:slot_id>', methods=['POST'])
def admin_delete_slot(slot_id):
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    db.execute('DELETE FROM Time_Slots WHERE slot_id=?', (slot_id,))
    db.commit()
    db.close()
    return redirect('/admin/timeslots')

@app.route('/admin/timeslots/open/<int:slot_id>', methods=['POST'])
def admin_open_slot(slot_id):
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    db.execute('UPDATE Time_Slots SET is_available=1 WHERE slot_id=?', (slot_id,))
    db.commit()
    db.close()
    return redirect('/admin/timeslots')

@app.route('/admin/providers')
def admin_providers():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    providers = db.execute("SELECT p.*, u.email, u.phone FROM providers p LEFT JOIN users u ON p.user_id=u.id ORDER BY p.id").fetchall()
    db.close()
    return render_template('admin_providers.html', user=user, providers=providers)

@app.route('/admin/providers/delete/<int:provider_id>', methods=['POST'])
def admin_delete_provider(provider_id):
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    db.execute('DELETE FROM providers WHERE id=?', (provider_id,))
    db.commit()
    db.close()
    return redirect('/admin/providers')

@app.route('/admin/users')
def admin_users():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    all_users = db.execute("SELECT * FROM users WHERE role != 'Administrator' ORDER BY id DESC").fetchall()
    db.close()
    return render_template('admin_users.html', user=user, all_users=all_users)

@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
def admin_delete_user(user_id):
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    db.execute('DELETE FROM users WHERE id=?', (user_id,))
    db.commit()
    db.close()
    return redirect('/admin/users')

@app.route('/admin/reports')
def admin_reports():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    appts = db.execute("SELECT a.*, p.full_name as provider_name FROM appointments a LEFT JOIN providers p ON a.provider_id=p.id ORDER BY a.appointment_date DESC").fetchall()
    providers = db.execute('SELECT * FROM providers ORDER BY id').fetchall()

    total_appts = len(appts)
    completed = len([a for a in appts if a['status'] == 'Completed'])
    pending = len([a for a in appts if a['status'] == 'Pending'])
    cancelled = len([a for a in appts if a['status'] == 'Cancelled'])
    awaiting = len([a for a in appts if a['status'] == 'Awaiting Approval'])

    def pct(n):
        return int((n / total_appts) * 100) if total_appts > 0 else 0

    db.close()

    stats = {
        'providers': len(providers),
        'total_appointments': total_appts,
        'patients': db.execute("SELECT COUNT(*) FROM users WHERE role='Customer'").fetchone()[0] if False else 0,
        'completed_pct': pct(completed),
        'pending_pct': pct(pending),
        'cancelled_pct': pct(cancelled),
        'awaiting_pct': pct(awaiting),
        # keep raw counts available for future use
        'completed': completed,
        'pending': pending,
        'cancelled': cancelled,
        'awaiting': awaiting,
    }

    # Need a short re-open because patients count is not available after db.close()
    db2 = get_db()
    stats['patients'] = db2.execute("SELECT COUNT(*) FROM users WHERE role='Customer'").fetchone()[0]
    db2.close()

    return render_template('admin_reports.html', user=user, appointments=appts, stats=stats, providers=providers)

@app.route('/admin/notifications')
def admin_notifications():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    notifs = db.execute("SELECT n.*, u.first_name||' '||u.last_name AS recipient FROM Notifications n LEFT JOIN users u ON n.user_id=u.id ORDER BY n.sent_at DESC").fetchall()
    db.close()
    return render_template('admin_notifications.html', user=user, notifications=notifs)

@app.route('/admin/profile', methods=['GET', 'POST'])
def admin_profile():
    user = admin_required()
    if not user:
        return redirect('/signin')
    db = get_db()
    admin_user = db.execute("SELECT * FROM users WHERE email=?", (user['email'],)).fetchone()
    if request.method == 'POST':
        db.execute('UPDATE users SET first_name=?,last_name=?,phone=? WHERE email=?', (request.form.get('first_name'),request.form.get('last_name'),request.form.get('phone'),user['email']))
        db.commit()
        session['user']['name'] = request.form.get('first_name', 'Admin')
    db.close()
    return render_template('admin_profile.html', user=user, admin_user=admin_user)


if __name__ == '__main__':
    init_db()
    seed_data()
    app.run(debug=True)